create procedure transfermoneycard(IN receiverp character varying, IN senderp bigint, IN amountp numeric)
    language plpgsql
as
$$
DECLARE
    sender_card_number_prefix VARCHAR(4);
    sender_balance            DECIMAL;
    ccyP varchar(5);
BEGIN

    SELECT SUBSTRING(card_number FROM 1 FOR 4), amount,ccy
    INTO sender_card_number_prefix, sender_balance,ccyP
    FROM bank_customer_schema.card
    WHERE id = senderP;

    IF amountP > sender_balance THEN
        RAISE EXCEPTION 'Balans yoxdur';
        RETURN;
    END IF;

    UPDATE bank_customer_schema.card
    SET amount = amount - amountP
    WHERE id = senderP;

    UPDATE bank_customer_schema.card
    SET amount = amount + amountP
    WHERE card_number = receiverP;

    IF SUBSTRING(receiverP, 1, 4) != sender_card_number_prefix THEN
        UPDATE bank_customer_schema.card
        set amount = amount - (amountP * 1.05)
        where id = senderP;
    END IF;

    insert into bank_customer_schema.transactions(sender, receiver, ccy, amount)
    VALUES(senderP,receiverP,ccyP,amountP);

END;
$$;

alter procedure transfermoneycard(varchar, bigint, numeric) owner to postgres;

