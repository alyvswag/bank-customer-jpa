create procedure deletecustomer(IN idp bigint)
    language plpgsql
as
$$
begin
    update bank_customer_schema.customer c
    set is_active = false
    where c.id = idP;

end;
$$;

alter procedure deletecustomer(bigint) owner to postgres;

