create procedure addcustomer(IN namep character varying, IN surnamep character varying, IN birth_datep date, IN finp character varying)
    language plpgsql
as
$$
begin
    insert into bank_customer_schema.customer(name, surname, birth_date, fin)
    values (nameP, surnameP, birth_dateP, finP);

    commit ;
end;
$$;

alter procedure addcustomer(varchar, varchar, date, varchar) owner to postgres;

