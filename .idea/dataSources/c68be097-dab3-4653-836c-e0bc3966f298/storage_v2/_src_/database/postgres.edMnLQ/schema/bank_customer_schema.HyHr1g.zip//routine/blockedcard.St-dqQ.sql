create procedure blockedcard(IN idp bigint)
    language plpgsql
as
$$
begin
    update bank_customer_schema.card c
    set status = 'INACTIVE'
    where id = idP;
end;
$$;

alter procedure blockedcard(bigint) owner to postgres;

