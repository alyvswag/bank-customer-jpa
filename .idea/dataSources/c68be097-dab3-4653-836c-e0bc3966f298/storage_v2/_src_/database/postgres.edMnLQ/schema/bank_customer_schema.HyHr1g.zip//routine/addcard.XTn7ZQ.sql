create procedure addcard(IN customer_idp bigint, IN card_numberp character varying, IN exp_datep date, IN cvvp character varying, IN ccyp character varying, IN amountp numeric)
    language plpgsql
as
$$
begin
    insert into bank_customer_schema.card(customer_id, card_number, exp_date, cvv, ccy, amount)
    values (customer_idP, card_numberP, exp_dateP, cvvP, ccyP, amountP);
commit;
end;
$$;

alter procedure addcard(bigint, varchar, date, varchar, varchar, numeric) owner to postgres;

