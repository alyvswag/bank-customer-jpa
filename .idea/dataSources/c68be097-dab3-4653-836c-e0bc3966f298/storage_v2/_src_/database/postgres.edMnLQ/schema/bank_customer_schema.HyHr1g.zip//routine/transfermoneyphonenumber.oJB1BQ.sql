create procedure transfermoneyphonenumber(IN receiverp character varying, IN senderp bigint, IN amountp numeric)
    language plpgsql
as
$$
declare
    sender_balance decimal;
    ccyP varchar(5);
begin

    select amount,ccy
    into sender_balance,ccyp
    from bank_customer_schema.card
    where id = senderP;

    IF amountP > sender_balance THEN
        RAISE EXCEPTION 'Balans yoxdur';
        RETURN;
    END IF;

    update bank_customer_schema.card
    set amount = amount - amountP
    where id = senderP;

    insert into bank_customer_schema.transactions(sender, receiver, ccy, amount)
    VALUES(senderP,receiverP,ccyP,amountP);
end;
$$;

alter procedure transfermoneyphonenumber(varchar, bigint, numeric) owner to postgres;

